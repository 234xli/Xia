package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import beans.JDBCUtil;

/**
 * Servlet implementation class Alter2
 */
@WebServlet("/Alter2")
public class Alter2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String id= (String) request.getSession().getAttribute("ID");
		String ID =  request.getParameter("ID2");
		String Name = request.getParameter("name2");	
		String SClass = request.getParameter("SClass");
		String Phone = request.getParameter("phone");
		String info ="";
		int n = 0;
		    Connection conn=null;
		    PreparedStatement ps=null;
	
		    try{
				conn=JDBCUtil.getConnection();
				String sql = "update information set ID=?,name = ? , SClass= ? , phone = ?  where ID = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1,ID);
				ps.setString(2,Name);
				ps.setString(3,SClass);
				ps.setString(4,Phone);
				ps.setString(5,id);
				n = ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
	
				if(n<=0) {
					info = "修改失败！";
				}
				else {
					
						info = "修改成功！";
					}
			request.setAttribute("info", info);
			RequestDispatcher rd = request.getRequestDispatcher("altershow.jsp");
			rd.forward(request, response);
		    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
