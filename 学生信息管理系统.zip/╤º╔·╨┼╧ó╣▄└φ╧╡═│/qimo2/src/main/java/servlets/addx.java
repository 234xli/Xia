package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.JDBCUtil;

/**
 * Servlet implementation class addx
 */
@WebServlet("/addx")
public class addx extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addx() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String ID = request.getParameter("ID");
		String Name = request.getParameter("name");	
		String SClass = request.getParameter("cl");
		String Phone = request.getParameter("phone");
		String info ="";
		int n = 0;
		int m=0;
		    Connection conn=null;
		    PreparedStatement ps=null;
	
		    try{
				conn=JDBCUtil.getConnection();
				String sql = "select * from information where ID=?";
				ps = conn.prepareStatement(sql);
				ps.setString(1,ID);
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					n = n+1;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
	
				if(n>0) {
					info = "该学号已存在！";
				}
				else {
					try{
						conn=JDBCUtil.getConnection();
						String sql="insert into information(ID,name,SClass,phone)  values (?,?,?,?)";
						ps=conn.prepareStatement(sql);
						ps.setString(1, ID);
						ps.setString(2, Name);
						ps.setString(3, SClass);
						ps.setString(4, Phone);
						m = ps.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						JDBCUtil.free(null, ps, conn);
					}
			
					if(m>0) {
						info = "增加学生信息成功！";
					}
					else {
						info = "增加学生信息失败！";
					}
				}
			request.setAttribute("info", info);
			RequestDispatcher rd = request.getRequestDispatcher("add.jsp");
			rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
