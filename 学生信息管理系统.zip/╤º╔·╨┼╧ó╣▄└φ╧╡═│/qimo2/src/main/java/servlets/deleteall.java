package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.JDBCUtil;

/**
 * Servlet implementation class deleteall
 */
@WebServlet("/deleteall")
public class deleteall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteall() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String info ="";
		int n = 0;
		    Connection conn=null;
		    PreparedStatement ps=null;
	
		    try{
		    	conn=JDBCUtil.getConnection();
				String sql="delete from recycle";
				ps=conn.prepareStatement(sql);
				n = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
	
				if(n<=0) {
					info = "删除失败或回收站没有信息记录！";
				}
				else {
					info = "删除成功！";
				}
				request.setAttribute("info", info);
				RequestDispatcher rd = request.getRequestDispatcher("List_recycle.jsp");
				rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
