package beans;

public class Student {
	private String ID;
	private String name;
	private String SClass;
	private String phone;
	public String getID() {
		return ID;
	}
	public void setID(String id) {
		ID = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSClass() {
		return SClass;
	}
	public void setSClass(String class1) {
		SClass = class1;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	

}
