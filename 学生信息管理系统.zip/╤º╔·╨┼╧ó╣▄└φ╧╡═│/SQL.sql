create database qimo;
use qimo;
create table [user](
userid varchar(30) primary key,
password varchar(30)
)

create table information(
ID varchar(30) primary key,
name varchar(30),
SClass varchar(30),
phone varchar(30)
)

create table recycle(
ID varchar(30) primary key,
name varchar(30),
SClass varchar(30),
phone varchar(30)
)