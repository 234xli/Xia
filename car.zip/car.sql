DROP DATABASE IF EXISTS `car`;
CREATE DATABASE `car`;

USE `car`;

DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `cars`;

CREATE TABLE `users`(
	`ID` INT(10) PRIMARY KEY AUTO_INCREMENT COMMENT 'ID',
	`userName` VARCHAR(20) NOT NULL COMMENT '用户名',
	`password` VARCHAR(20) NOT NULL COMMENT '密码',
	`petName` VARCHAR(20) NOT NULL COMMENT '昵称',
  `name` VARCHAR(20) NOT NULL COMMENT '姓名',
  `sex` VARCHAR(4) NOT NULL COMMENT '性别'
)DEFAULT CHARSET=utf8;

CREATE TABLE `cars`(
	`ID` INT(10) PRIMARY KEY AUTO_INCREMENT COMMENT 'ID',
	`brand` VARCHAR(20) NOT NULL COMMENT '品牌',
	`color` VARCHAR(20) NOT NULL COMMENT '颜色',
	`seatingNum` INT(10) NOT NULL COMMENT '座位数',
  `oilCon` Decimal(8,1) NOT NULL COMMENT '百公里油耗',
  `dailyRent` INT(10) NOT NULL COMMENT '日租金',
  `addedByPeople` INT(10) NOT NULL COMMENT '添加人',
  FOREIGN KEY (`addedByPeople`) REFERENCES `users`(`ID`)
)DEFAULT CHARSET=utf8;
INSERT INTO `users`(`ID`, `userName`, `password`, `petName`,`name`,`sex`)VALUES
(1,'xia','123','nicheng','xiajiaxing','男'),
(2,'dj','1234','ni','xi','女');
INSERT INTO `cars`(`ID`, `brand`, `color`, `seatingNum`,`oilCon`,`dailyRent`,`addedByPeople`)VALUES
(1,'奥迪','黑色',3,50.3,100,'1'),
(2,'别克','红色',4,60.2,120,'2');

SELECT * FROM `users`;
SELECT * FROM `cars`;
