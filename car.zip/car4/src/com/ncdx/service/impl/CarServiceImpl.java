package com.ncdx.service.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import com.ncdx.pojo.Car;
import com.ncdx.service.CarService;
import com.ncdx.util.MybatisUtil;
@Service
public class CarServiceImpl implements CarService{
	@Override
	public List<Car> queryAllCar() {
		SqlSession ss=MybatisUtil.init().getSqlSession();
		List<Car> ps=ss.selectList("com.ncdx.dao.CarDao.queryAllCar");

		ss.close();
		return ps;
	}

	@Override
	public Car queryCarById(int id) {
		SqlSession ss=MybatisUtil.init().getSqlSession();
		
		Car p=ss.selectOne("com.ncdx.dao.CarDao.queryCarById", id);
		
		ss.close();
		return p;
	}

	@Override
	public int addCar(Car car) {
		SqlSession ss=MybatisUtil.init().getSqlSession();
		int flag=ss.update("com.ncdx.dao.CarDao.addCar", car);
		ss.commit();
		ss.close();
		return flag;
	}

	@Override
	public int deleteCar(int id) {
		SqlSession ss=MybatisUtil.init().getSqlSession();
		int flag=ss.update("com.ncdx.dao.CarDao.deleteCar",id);
		ss.commit();
		ss.close();
		return flag;
	}
}
