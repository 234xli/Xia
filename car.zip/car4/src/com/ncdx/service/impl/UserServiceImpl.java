package com.ncdx.service.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import com.ncdx.pojo.User;
import com.ncdx.service.UserService;
import com.ncdx.util.MybatisUtil;
@Service
public class UserServiceImpl implements UserService {
	
	public User queryUserById(int id){
        SqlSession ss=MybatisUtil.init().getSqlSession();
		User u=ss.selectOne("com.ncdx.dao.UserDao.queryUserById", id);
		ss.close();
		return u;
	}
	/**
	 * 根据用户名查询用户
	 */
	public User queryUserByUserName(String userName){
		SqlSession ss=MybatisUtil.init().getSqlSession();
		User u=ss.selectOne("com.ncdx.dao.UserDao.queryUserByUserName", userName);
		ss.close();
		return u;
	}
}
