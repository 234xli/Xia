package com.ncdx.service;

import com.ncdx.pojo.User;

public interface UserService {
	/**
	 * 根据ID查询用户
	 */
	public User queryUserById(int id);
	/**
	 * 根据用户名查询用户
	 */
	public User queryUserByUserName(String userName);
}
