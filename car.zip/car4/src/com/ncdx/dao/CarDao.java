package com.ncdx.dao;

import java.util.List;

import com.ncdx.pojo.Car;

public interface CarDao {
	/**
	 * 查询所有汽车
	 */
	public List<Car> queryAllCar();
	/**
	 * 根据ID查询汽车
	 */
	public Car queryCarById(int id);
	/**
	 * 新增汽车
	 */
	public int addCar(Car car);
	/**
	 * 根据id删除汽车
	 */
	public int deleteCar(int id);
}
