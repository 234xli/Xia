package com.ncdx.dao;

import com.ncdx.pojo.User;

public interface UserDao {
	/**
	 * 根据ID查询用户
	 */
	public User queryUserById(int id);
	/**
	 * 根据用户名查询用户
	 */
	public User queryUserByUserName(String userName);
	
}
