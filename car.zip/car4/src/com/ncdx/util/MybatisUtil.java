package com.ncdx.util;

import java.io.InputStream;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisUtil {
	private SqlSessionFactory factory;
	private static MybatisUtil mu=new MybatisUtil();
	/**
	 * static:用static修饰的成员为静态成员,静态成员只在类加载的时候执行一遍
	 * 单例模式:保证内存中只存在一个该类型的实例
	 * 		1. 私有化构造方法
	 * 		2. 定义一个静态的私有的本类类型变量并且实例化
	 * 		3. 提供一个公共的静态的方法,返回本类类型变量
	 * 
	 * 作用:
	 * 		1. 获取数据库连接
	 * 		2. 关闭资源
	 */
	private MybatisUtil() {
		/*
		 * 1. 没有返回值
		 * 2. 方法名和类名一致
		 * 创建对象的时候调用构造方法,也可以做初始化工作Class
		 */
		InputStream is=MybatisUtil.class.getClassLoader().getResourceAsStream("mybatis.xml");
		factory=new SqlSessionFactoryBuilder().build(is);
	}
	public static MybatisUtil init() {
		return mu;
	}
	public SqlSession getSqlSession() {
		return factory.openSession();
	}
}
