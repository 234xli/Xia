package com.ncdx.controller;

import java.util.List;


import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ncdx.pojo.Car;
import com.ncdx.pojo.User;
import com.ncdx.service.CarService;
import com.ncdx.service.UserService;

@Controller
@RequestMapping("/car4")
public class CarController {
	@Autowired
    @Qualifier("carServiceImpl")
    private CarService carService;
	
	@Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;
	
    //查看详细信息
	@RequestMapping("/findDetail")
	public String findDetail(Model model,int ID){
		Car car = carService.queryCarById(ID);
		model.addAttribute("car",car);
		return "findDetail";
		
	}
	
	// 查询出来的数据库里全部书籍
    @RequestMapping("/function")
    public String list(Model model) {
    	List<Car> list = carService.queryAllCar();
        model.addAttribute("list", list);
        return "function";
    }
    //删除汽车
    @RequestMapping("/delCar")
    public String delCar(Model model,int ID) {
    	carService.deleteCar(ID);
    	return "redirect:/car4/function";
    }
    
    //跳转到新增汽车界面
    @RequestMapping("/toAddCar")
    public String toAddCar(Model model) {
        return "addCar";
    }
    //新增汽车
    @RequestMapping("/addCar")
    public String addCar(HttpSession session,Model model,Car car) {
    		car.setAddedByPeople((User)session.getAttribute("u"));
        	carService.addCar(car);
        	return "redirect:/car4/function";
    	
    }
    
    //删除所选
    @RequestMapping("/delSelect")
    public String delSelect(Model model,String ids) {
        String[] split = ids.split(",");
    		for(int i=0;i<split.length;i++){
        		carService.deleteCar(Integer.parseInt(split[i]));
        	}
    	
    	return "redirect:/car4/function";
    }
    //回到列表页
    @RequestMapping("/toFunction")
    public String toFunction(Model model) {
        return "redirect:/car4/function";
    }
}
