package com.ncdx.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ncdx.pojo.User;
import com.ncdx.service.UserService;

@Controller
@RequestMapping("/car4")
public class UserController {
	@Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;
	
	 //跳转到登录页面
    @RequestMapping("/toLogin")
    public String toLogin(Model model) {
        return "login";
    }
    
 // 登录
    @RequestMapping("/login")
    public String login(HttpSession session,String userName,String password) {
    	User u = userService.queryUserByUserName(userName);
    	session.setAttribute("userName", userName);
    	session.setAttribute("u", u);
    	if(u==null || !password.equals(u.getPassword())){
    		session.setAttribute("info", "用户名或密码错误");
    		return "login";
    	}
    	return "redirect:/car4/function";
        
    }
}
