package com.ncdx.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
public class Car {
	private int ID;
	private String brand;
	private String color;
	private Integer seatingNum;
	private Double oilCon;
	private Integer dailyRent;
	private User addedByPeople;
	
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Integer getSeatingNum() {
		return seatingNum;
	}

	public void setSeatingNum(Integer seatingNum) {
		this.seatingNum = seatingNum;
	}

	public Double getOilCon() {
		return oilCon;
	}

	public void setOilCon(Double oilCon) {
		this.oilCon = oilCon;
	}

	public Integer getDailyRent() {
		return dailyRent;
	}

	public void setDailyRent(Integer dailyRent) {
		this.dailyRent = dailyRent;
	}

	public User getAddedByPeople() {
		return addedByPeople;
	}

	public void setAddedByPeople(User addedByPeople) {
		this.addedByPeople = addedByPeople;
	}

	@Override
	public String toString() {
		return "Car [ID=" + ID + ", brand=" + brand + ", color=" + color + ", seatingNum=" + seatingNum + ", oilCon="
				+ oilCon + ", dailyRent=" + dailyRent + ", addedByPeople=" + addedByPeople + "]";
	}
	
	
	
}
