package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.JDBCUtil;
import beans.Student;

/**
 * Servlet implementation class huanyuan
 */
@WebServlet("/huanyuan")
public class huanyuan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public huanyuan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String ID = request.getParameter("ID");
		String info ="";
		int n = 0;
		int m=0;
		int p = 0;
		    Connection conn=null;
		    PreparedStatement ps=null;
		    Student stu = new Student();
					try{
						conn=JDBCUtil.getConnection();
						String sql = "select * from recycle where ID=?";
						ps = conn.prepareStatement(sql);
						ps.setString(1,ID);
						ResultSet rs = ps.executeQuery();
						if(rs.next()){
							
							stu.setID(rs.getString(1));
							stu.setName(rs.getString(2));
							stu.setSClass(rs.getString(3));
							stu.setPhone(rs.getString(4));
							n = n+1;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						JDBCUtil.free(null, ps, conn);
					}
					if(n<=0) {
						info = "该学号不在回收站！";
					}
					else {
					
					try{
						conn=JDBCUtil.getConnection();
						conn.setAutoCommit(false);//通知数据库开启事务(start transaction)
						String sql="delete from recycle where ID=?";
						ps=conn.prepareStatement(sql);
						ps.setString(1, ID);
						p = ps.executeUpdate();
						String sql2="insert into information(ID,name,SClass,phone)  values (?,?,?,?)";
						ps=conn.prepareStatement(sql2);
						ps.setString(1, ID);
						ps.setString(2,stu.getName());
						ps.setString(3,stu.getSClass());
						ps.setString(4,stu.getPhone());	
						m = ps.executeUpdate();
						 conn.commit();//上面的两条SQL执行Update语句成功之后就通知数据库提交事务(commit)
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						JDBCUtil.free(null, ps, conn);
					}
			
					if(p>0 && m>0) {
						info = "还原成功！";
					}
					else if(p>0 && m<=0){
						info = "增加信息到信息表中失败导致还原失败！";
					}
					else if(p<=0 && m>0) {
						info="从回收站删除信息失败导致还原失败！";
					}
					else {
						info="还原失败！";
					}
				}
			request.setAttribute("info", info);
			RequestDispatcher rd = request.getRequestDispatcher("huanyuan_recycle.jsp");
			rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
