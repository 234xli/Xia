package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.JDBCUtil;


public class LoginCheckServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
		 * Constructor of the object.
		 */
	public LoginCheckServlet() {
		super();
	}

	/**
		 * Destruction of the servlet. <br>
		 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
		 * The doGet method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to get.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
	}

	/**
		 * The doPost method of the servlet. <br>
		 *
		 * This method is called when a form has its tag value method equals to post.
		 * 
		 * @param request the request send by the client to the server
		 * @param response the response send by the server to the client
		 * @throws ServletException if an error occurred
		 * @throws IOException if an error occurred
		 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");;
		String Userid = request.getParameter("userid");
		String Password = request.getParameter("userpwd");	
		String usercheckcode = request.getParameter("checkcode");

		HttpSession session = request.getSession();
		String servercheckcode = (String)session .getAttribute("checkCode");
		System.out.println(servercheckcode);
		int n = 0;
		String info ="";
			Connection conn=null;
			PreparedStatement ps=null;
	
			try{
				conn=JDBCUtil.getConnection();
				String sql = "select * from user where userid=? and password=?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, Userid);
				ps.setString(2, Password);
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					n = n+1;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
	
			if(!servercheckcode.equalsIgnoreCase(usercheckcode)) {
				info = "验证码输入不正确，请重新输入！";
			}
			else {
				if(n>0) {
					RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
					rd.forward(request, response);
				}
				else {
					info = "用户名或密码不正确！";
				}
			}

			request.setAttribute("info", info);
			RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
			rd.forward(request, response);
	}

	/**
		 * Initialization of the servlet. <br>
		 *
		 * @throws ServletException if an error occurs
		 */

	public void init() throws ServletException {
		// Put your code here
	}

}
