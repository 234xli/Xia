package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Student;
import beans.JDBCUtil;

/**
 * Servlet implementation class Find
 */
@WebServlet("/Find")
public class Find extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Find() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");;
		String ID = request.getParameter("ID");
		String info ="";
		int n = 0;
		Student stu = null;
		    Connection conn=null;
		    PreparedStatement ps=null;
	
		    try{
				conn=JDBCUtil.getConnection();
				String sql = "select * from information where ID=?";
				ps = conn.prepareStatement(sql);
				ps.setString(1,ID);
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					stu=new Student();
					stu.setID(rs.getString(1));
					stu.setName(rs.getString(2));
					stu.setSClass(rs.getString(3));
					stu.setPhone(rs.getString(4));
					n = n+1;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
	
				if(n<=0) {
					info = "该学号不存在！";
					request.setAttribute("info", info);
					RequestDispatcher rd = request.getRequestDispatcher("find.jsp");
					rd.forward(request, response);
				}
				else {
					request.getSession().setAttribute("Student", stu);
					RequestDispatcher rd = request.getRequestDispatcher("findshow.jsp");
					rd.forward(request, response);
				}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
