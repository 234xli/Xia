package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ListDao {
	
	
	//查询所有学生信息的方法
	public List<Student> QueryAll() throws Exception{
		    Connection conn=null;
		    PreparedStatement ps=null;
		    ResultSet rs = null;
		    List<Student>studentList = new ArrayList<Student>();
		    try{
				conn=JDBCUtil.getConnection();
				String sql = "select * from information";
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while(rs.next()){
					Student stu=new Student();
					stu.setID(rs.getString(1));
					stu.setName(rs.getString(2));
					stu.setSClass(rs.getString(3));
					stu.setPhone(rs.getString(4));
					studentList.add(stu);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				JDBCUtil.free(null, ps, conn);
			}
			return studentList; 
	}

	//查询回收站的方法
			public List<Student> QueryAll2() throws Exception{
				    Connection conn=null;
				    PreparedStatement ps=null;
				    ResultSet rs = null;
				    List<Student>studentList2 = new ArrayList<Student>();
				    try{
						conn=JDBCUtil.getConnection();
						String sql = "select * from recycle";
						ps = conn.prepareStatement(sql);
						rs = ps.executeQuery();
						while(rs.next()){
							Student stu=new Student();
							stu.setID(rs.getString(1));
							stu.setName(rs.getString(2));
							stu.setSClass(rs.getString(3));
							stu.setPhone(rs.getString(4));
							studentList2.add(stu);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
						JDBCUtil.free(null, ps, conn);
					}
					return studentList2; 
			}

}
